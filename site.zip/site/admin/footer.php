  </main>
  <footer class="bg-white border-top mt-4 py-3">
    <div class="container text-center text-muted">
      &copy; <?= date('Y') ?> PrintLab 3D Admin
    </div>
  </footer>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
         ></script>
</body>
</html>
